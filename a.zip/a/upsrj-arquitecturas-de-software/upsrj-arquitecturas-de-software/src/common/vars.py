import os

# REPOSITORY FILES
PRODUCTS_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "products_service", "products.json")
USERS_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "users_service", "users.json")
PURCHASES_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "purchases_service", "purchases.json")

# SERVICE URL's (Servicios principales)
GATEWAY_SERVICE_URL = "http://localhost:5000"        
USER_SERVICE_URL = "http://localhost:5002"       
PRODUCT_SERVICE_URL = "http://localhost:5004"      
PURCHASES_SERVICE_URL = "http://localhost:5006"  

# REST API URL's (APIs específicas)
GATEWAY_API_URL = "http://localhost:5001"        
USER_API_URL = "http://localhost:5003"           
PRODUCT_API_URL = "http://localhost:5005"        
PURCHASES_API_URL = "http://localhost:5007"